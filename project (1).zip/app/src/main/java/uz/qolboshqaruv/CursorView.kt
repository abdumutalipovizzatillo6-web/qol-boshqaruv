package uz.qolboshqaruv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View

/** Butun ekran ustidagi shaffof qatlam: kursor, qo'l skeleti, yozuvlar. Teginishni o'tkazib yuboradi. */
class CursorView(context: Context) : View(context) {

    companion object {
        private val CONN = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17
        )
    }

    private val dp = resources.displayMetrics.density

    @Volatile
    var hand: FloatArray? = null
    var curX = 0f
    var curY = 0f
    var show = false
    var label = ""
    var ringColor = 0xFF4FC3F7.toInt()
    var pinching = false
    var fist = 0f
    var showSkeleton = true

    private var msg = ""
    private var msgUntil = 0L
    private var rx = 0f
    private var ry = 0f
    private var rt = 0L

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB3FFFFFF.toInt()
        strokeWidth = 2f * dp
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f * dp
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6.5f * dp
        color = 0x55000000
    }
    private val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC000000.toInt()
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * dp
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun showMessage(t: String) {
        msg = t
        msgUntil = SystemClock.uptimeMillis() + 1400L
        postInvalidateOnAnimation()
    }

    fun ripple(x: Float, y: Float) {
        rx = x
        ry = y
        rt = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        var animating = false
        val h = hand

        if (show && h != null && h.size >= 42) {
            if (showSkeleton) {
                var i = 0
                while (i < CONN.size) {
                    val a = CONN[i]
                    val b = CONN[i + 1]
                    c.drawLine(h[2 * a], h[2 * a + 1], h[2 * b], h[2 * b + 1], linePaint)
                    i += 2
                }
                for (k in 0 until 21) {
                    c.drawCircle(h[2 * k], h[2 * k + 1], 3f * dp, dotPaint)
                }
            }

            val r = (if (pinching) 14f else 22f) * dp
            c.drawCircle(curX, curY, r, shadowPaint)
            if (pinching) {
                fillPaint.color = (ringColor and 0x00FFFFFF) or 0x99000000.toInt()
                c.drawCircle(curX, curY, r, fillPaint)
            }
            ringPaint.color = ringColor
            ringPaint.alpha = 255
            c.drawCircle(curX, curY, r, ringPaint)

            if (fist > 0f) {
                val rr = r + 8f * dp
                rect.set(curX - rr, curY - rr, curX + rr, curY + rr)
                ringPaint.color = 0xFFFB923C.toInt()
                c.drawArc(rect, -90f, 360f * fist, false, ringPaint)
            }
        }

        if (show && label.isNotEmpty()) {
            drawPill(c, label, width / 2f, 72f * dp)
        }
        if (now < msgUntil) {
            drawPill(c, msg, width / 2f, height - 150f * dp)
            animating = true
        }

        val age = now - rt
        if (rt != 0L && age < 450L) {
            val f = age / 450f
            ringPaint.color = 0xFF4ADE80.toInt()
            ringPaint.alpha = (255 * (1f - f)).toInt()
            c.drawCircle(rx, ry, (14f + 40f * f) * dp, ringPaint)
            ringPaint.alpha = 255
            animating = true
        }

        if (animating) postInvalidateOnAnimation()
    }

    private fun drawPill(c: Canvas, text: String, cx: Float, cy: Float) {
        val w = textPaint.measureText(text) + 28f * dp
        val hh = 34f * dp
        rect.set(cx - w / 2f, cy - hh / 2f, cx + w / 2f, cy + hh / 2f)
        c.drawRoundRect(rect, hh / 2f, hh / 2f, pillPaint)
        val fm = textPaint.fontMetrics
        c.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }
}
