package uz.qolboshqaruv

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var tvCam: TextView
    private lateinit var tvA11y: TextView
    private lateinit var tvRun: TextView
    private lateinit var gpuBtn: Button
    private lateinit var skelBtn: Button
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(6), 0, dp(6))
        return tv
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bg = 0xFF0F1115.toInt()
        val fg = 0xFFEEF0F4.toInt()
        val sub = 0xFF9AA3B5.toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(36), dp(20), dp(28))

        root.addView(label("✋ Qol bilan boshqarish", 26f, fg, true))
        root.addView(
            label(
                "Old kamera qo'lingizni kuzatadi va telefonni tegmasdan boshqarasiz: " +
                    "bosh ekrandagi va boshqa ilovalarda kursor ko'rinadi.",
                14f, sub
            )
        )

        root.addView(label("1-qadam", 13f, sub))
        tvCam = label("", 16f, fg, true)
        root.addView(tvCam)
        root.addView(button("Kameraga ruxsat berish") { askPermissions() })

        root.addView(label("2-qadam", 13f, sub))
        tvA11y = label("", 16f, fg, true)
        root.addView(tvA11y)
        root.addView(
            label(
                "Maxsus imkoniyatlar → «Qol boshqaruv» → yoqing. Agar yoqib bo'lmasa (Android 13+): " +
                    "«Ilova sozlamalari» → ⋮ (yuqori o'ng) → «Cheklangan sozlamalarga ruxsat berish», keyin qayta urinib ko'ring.",
                13f, sub
            )
        )
        root.addView(button("Maxsus imkoniyatlarni ochish") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Ilova sozlamalari (cheklangan sozlama)") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })

        root.addView(label("3-qadam", 13f, sub))
        tvRun = label("", 16f, fg, true)
        root.addView(tvRun)
        root.addView(button("▶ Boshlash") { start() })
        root.addView(button("■ To'xtatish") { stopService(Intent(this, CameraService::class.java)); refreshLater() })

        root.addView(label("Tezlik sozlamalari", 18f, fg, true))
        gpuBtn = button("") {
            Prefs.setGpu(this, !Prefs.gpu(this))
            refresh()
            Toast.makeText(this, "O'zgarish uchun To'xtatib, qayta Boshlang", Toast.LENGTH_LONG).show()
        }
        root.addView(gpuBtn)
        skelBtn = button("") {
            Prefs.setSkeleton(this, !Prefs.skeleton(this))
            HandAccessibilityService.instance?.reloadPrefs()
            refresh()
        }
        root.addView(skelBtn)

        root.addView(label("Imo-ishoralar", 18f, fg, true))
        root.addView(
            label(
                "☝️ 1 barmoq — kursor\n" +
                    "🤏 Chimchilash — bosish (uzoq ushlab tursangiz: uzoq bosish; chimchilab sudrasangiz: surish)\n" +
                    "✌️ 2 barmoq — qo'lni tepaga/pastga/yonga yursangiz sahifa suriladi\n" +
                    "🤟 3 barmoq — qo'lni tugmadek burang: ovoz\n" +
                    "🤙 Shaka (bosh va jimjiloq ochiq) — qo'lni chapga qiyshaytiring: Orqaga, o'ngga qiyshaytiring: So'nggi ilovalar\n" +
                    "✊ Musht — 1 soniya ushlab turing: Bosh ekran",
                14f, sub
            )
        )

        root.addView(label("Xiaomi / Redmi uchun", 18f, fg, true))
        root.addView(
            label(
                "Ilova fonda to'xtab qolmasligi uchun: Sozlamalar → Ilovalar → Qol boshqaruv → " +
                    "«Avto-ishga tushirish» ni yoqing va Batareya tejash: «Cheklovsiz» ni tanlang. " +
                    "To'xtatish: bildirishnomadagi «To'xtatish» tugmasi.",
                13f, sub
            )
        )

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun camGranted(): Boolean =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, HandAccessibilityService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return s.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun refresh() {
        tvCam.text = (if (camGranted()) "✅" else "❌") + " Kamera ruxsati"
        tvA11y.text = (if (a11yEnabled()) "✅" else "❌") + " Maxsus imkoniyatlar yoqilgan"
        tvRun.text = if (CameraService.running) "🟢 Ishlayapti" else "⚪ To'xtagan"
        gpuBtn.text = if (Prefs.gpu(this)) "⚡ GPU rejimi: YOQILGAN (tezroq)" else "⚡ GPU rejimi: O'CHIQ (CPU)"
        skelBtn.text = if (Prefs.skeleton(this)) "🖐 Qo'l skeleti: YOQILGAN" else "🖐 Qo'l skeleti: O'CHIQ (yengilroq)"
    }

    private fun refreshLater() {
        handler.postDelayed({ refresh() }, 600L)
    }

    private fun askPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.CAMERA)
        }
        requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun start() {
        if (!camGranted()) {
            Toast.makeText(this, "Avval kameraga ruxsat bering", Toast.LENGTH_LONG).show()
            return
        }
        if (!a11yEnabled()) {
            Toast.makeText(this, "Avval Maxsus imkoniyatlarda yoqing", Toast.LENGTH_LONG).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        Toast.makeText(this, "Ishga tushdi. Qo'lingizni old kameraga ko'rsating", Toast.LENGTH_LONG).show()
        refreshLater()
        moveTaskToBack(true)
    }
}
