package uz.qolboshqaruv

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Old kamerani fonda ishlatadi (foreground service), qo'lni aniqlaydi va HandAccessibilityService'ga yuboradi. */
class CameraService : LifecycleService() {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "uz.qolboshqaruv.STOP"
        private const val CHANNEL = "hand_control"
        private const val NOTIF_ID = 17
    }

    private val main = Handler(Looper.getMainLooper())
    private var executor: ExecutorService? = null
    private var provider: ProcessCameraProvider? = null
    private var landmarker: HandLandmarker? = null
    private var mirror = true
    private var lastTs = 0L

    // faqat executor oqimida ishlatiladi
    private var gpuOn = false
    private var errCount = 0

    @Volatile
    private var alive = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (!running) {
            running = true
            alive = true
            startPipeline()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Qol boshqaruv", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, CameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Qol bilan boshqarish yoqilgan")
            .setContentText("To'xtatish uchun bosing")
            .setContentIntent(openPi)
            .addAction(0, "To'xtatish", stopPi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun createLandmarker(gpu: Boolean): HandLandmarker {
        val bb = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) bb.setDelegate(Delegate.GPU)
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(bb.build())
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setRunningMode(RunningMode.VIDEO)
            .build()
        return HandLandmarker.createFromOptions(applicationContext, opts)
    }

    private fun startPipeline() {
        val ex = Executors.newSingleThreadExecutor()
        executor = ex
        ex.execute {
            var usingGpu = Prefs.gpu(applicationContext)
            var lm: HandLandmarker? = null
            if (usingGpu) {
                try {
                    lm = createLandmarker(true)
                } catch (e: Throwable) {
                    usingGpu = false
                }
            }
            if (lm == null) {
                try {
                    lm = createLandmarker(false)
                } catch (e: Throwable) {
                    main.post {
                        toast("Model yuklanmadi: " + e.message)
                        stopSelf()
                    }
                    return@execute
                }
            }
            landmarker = lm
            gpuOn = usingGpu
            val gpuFinal = usingGpu
            main.post {
                toast(if (gpuFinal) "Tezkor rejim (GPU)" else "Oddiy rejim (CPU)")
                bindCamera()
            }
        }
    }

    private fun bindCamera() {
        if (!alive) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val ex = executor
                if (!alive || ex == null) return@addListener
                val p = future.get()
                provider = p
                val selector = pickCamera(p)
                val resolution = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(320, 240),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(resolution)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(ex, ImageAnalysis.Analyzer { proxy -> analyze(proxy) })
                p.unbindAll()
                p.bindToLifecycle(this, selector, analysis)
            } catch (e: Exception) {
                toast("Kamera ochilmadi: " + e.message)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun pickCamera(p: ProcessCameraProvider): CameraSelector {
        return try {
            if (p.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
                mirror = true
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                mirror = false
                CameraSelector.DEFAULT_BACK_CAMERA
            }
        } catch (e: Exception) {
            mirror = false
            CameraSelector.DEFAULT_BACK_CAMERA
        }
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val lm = landmarker
            if (lm == null || !alive) return

            val bmp = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            // Burish MediaPipe ichida bajariladi (alohida rasm nusxasi kerak emas)
            val w = if (rot == 90 || rot == 270) bmp.height else bmp.width
            val h = if (rot == 90 || rot == 270) bmp.width else bmp.height

            val mp = BitmapImageBuilder(bmp).build()
            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts
            val opt = ImageProcessingOptions.builder().setRotationDegrees(rot).build()
            val result = lm.detectForVideo(mp, opt, ts)
            mp.close()
            bmp.recycle()
            errCount = 0

            val hands = result.landmarks()
            if (hands.isNotEmpty() && hands[0].size >= 21) {
                val l = hands[0]
                val arr = FloatArray(42)
                for (i in 0 until 21) {
                    arr[2 * i] = l[i].x()
                    arr[2 * i + 1] = l[i].y()
                }
                val mir = mirror
                main.post { HandAccessibilityService.instance?.onHand(arr, w, h, mir) }
            } else {
                main.post { HandAccessibilityService.instance?.onHandLost() }
            }
        } catch (e: Throwable) {
            errCount++
            if (errCount >= 8 && gpuOn) {
                // GPU ishlamayapti: CPU'ga o'tamiz
                errCount = 0
                gpuOn = false
                try {
                    landmarker?.close()
                } catch (e1: Throwable) {
                }
                try {
                    landmarker = createLandmarker(false)
                    main.post { toast("GPU ishlamadi, oddiy rejimga o'tildi") }
                } catch (e2: Throwable) {
                    landmarker = null
                }
            }
        } finally {
            proxy.close()
        }
    }

    private fun toast(t: String) {
        Toast.makeText(applicationContext, t, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        alive = false
        running = false
        try {
            provider?.unbindAll()
        } catch (e: Exception) {
        }
        val ex = executor
        ex?.execute {
            try {
                landmarker?.close()
            } catch (e: Throwable) {
            }
            landmarker = null
        }
        ex?.shutdown()
        executor = null
        HandAccessibilityService.instance?.onHandLost()
        super.onDestroy()
    }
}
