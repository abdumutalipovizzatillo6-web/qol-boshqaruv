package uz.qolboshqaruv

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Asosiy xizmat: ekran ustiga kursor qatlamini qo'yadi va qo'l imo-ishoralarini
 * haqiqiy bosish / surish / orqaga / bosh ekran amallariga aylantiradi.
 */
class HandAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HandAccessibilityService? = null
    }

    private var wm: WindowManager? = null
    private var view: CursorView? = null
    private var engine: GestureEngine? = null
    private var busy = false
    private var busyUntil = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val v = CursorView(this)
        view = v
        engine = GestureEngine(this, v)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            manager.addView(v, lp)
        } catch (e: Exception) {
            // qatlam qo'shilmadi
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        try {
            val v = view
            if (v != null) wm?.removeView(v)
        } catch (e: Exception) {
        }
        view = null
        engine = null
    }

    // ---------------- CameraService chaqiradi ----------------

    fun onHand(lm: FloatArray, w: Int, h: Int, mirror: Boolean) {
        engine?.onHand(lm, w, h, mirror)
    }

    fun onHandLost() {
        engine?.onLost()
    }

    // ---------------- GestureEngine ishlatadi ----------------

    fun screenW(): Int {
        val v = view
        if (v != null && v.width > 0) return v.width
        return metrics().widthPixels
    }

    fun screenH(): Int {
        val v = view
        if (v != null && v.height > 0) return v.height
        return metrics().heightPixels
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val m = wm
        if (m != null) {
            m.defaultDisplay.getRealMetrics(dm)
            return dm
        }
        return resources.displayMetrics
    }

    private fun clampTo(v: Float, max: Int): Float = v.coerceIn(2f, (max - 2).toFloat())

    fun tap(x: Float, y: Float, dur: Long = 45L) {
        val p = Path()
        p.moveTo(clampTo(x, screenW()), clampTo(y, screenH()))
        dispatch(p, dur)
    }

    fun swipe(x0: Float, y0: Float, x1: Float, y1: Float, dur: Long) {
        val w = screenW()
        val h = screenH()
        val p = Path()
        p.moveTo(clampTo(x0, w), clampTo(y0, h))
        p.lineTo(clampTo(x1, w), clampTo(y1, h))
        dispatch(p, dur)
    }

    fun isBusy(): Boolean = busy && SystemClock.uptimeMillis() < busyUntil

    private fun dispatch(path: Path, dur: Long): Boolean {
        val d = if (dur < 1L) 1L else dur
        val g = try {
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, d))
                .build()
        } catch (e: Exception) {
            return false
        }
        busy = true
        busyUntil = SystemClock.uptimeMillis() + d + 400L
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                busy = false
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                busy = false
            }
        }, null)
        if (!ok) busy = false
        return ok
    }

    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
        view?.showMessage("◁ Orqaga")
    }

    fun home() {
        performGlobalAction(GLOBAL_ACTION_HOME)
        view?.showMessage("○ Bosh ekran")
    }

    fun recents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        view?.showMessage("▢ So'nggi ilovalar")
    }

    fun volume(raise: Boolean) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (raise) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        } catch (e: Exception) {
        }
    }
}
