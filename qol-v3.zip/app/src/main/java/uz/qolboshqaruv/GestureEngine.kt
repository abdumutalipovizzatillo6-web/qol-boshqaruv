package uz.qolboshqaruv

import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Qo'l nuqtalaridan imo-ishorani aniqlaydi va telefonni boshqaradi.
 *
 *  ☝️ 1 barmoq      — kursor
 *  🤏 chimchilash   — bosish (ushlab tursangiz: uzoq bosish; sudrasangiz: surish)
 *  ✌️ 2 barmoq      — tepaga/pastga/yonga yursangiz sahifa suriladi
 *  🤟 3 barmoq      — qo'lni burish: ovoz
 *  🤙 shaka         — qo'lni chapga qiyshaytirish: Orqaga, o'ngga: So'nggi ilovalar
 *  ✊ musht         — 1 soniya ushlab turish: Bosh ekran
 */
class GestureEngine(private val svc: HandAccessibilityService, private val view: CursorView) {

    private enum class Mode { NONE, IDLE, POINT, PINCH, SCROLL, VOLUME, SHAKA, FIST }

    private var mode = Mode.NONE
    private var cand: Mode? = null
    private var candN = 0
    private var pinchOn = false

    // kursor (ekran koordinatasida)
    private var cx = -1f
    private var cy = -1f

    // chimchilash
    private var pinchStarted = false
    private var pinchT = 0L
    private var pinchX0 = 0f
    private var pinchY0 = 0f
    private var midX0 = 0f
    private var midY0 = 0f
    private var dragX = 0f
    private var dragY = 0f
    private var moved = 0f

    // aylantirish
    private var prevSX = Float.NaN
    private var prevSY = Float.NaN
    private var accX = 0f
    private var accY = 0f

    // ovoz
    private var volInit = false
    private var angSm = 0f
    private var volAcc = 0f

    // shaka (orqaga / so'nggi ilovalar)
    private var shInit = false
    private var shArmed = false
    private var shAng = 0f
    private var cooldown = 0L

    // musht
    private var fistStart = 0L
    private var fistDone = false

    private fun gx(a: FloatArray, i: Int): Float = a[2 * i]
    private fun gy(a: FloatArray, i: Int): Float = a[2 * i + 1]
    private fun dist(a: FloatArray, i: Int, j: Int): Float =
        hypot(gx(a, i) - gx(a, j), gy(a, i) - gy(a, j))

    /**
     * @param lm  21 ta nuqta, [x0, y0, x1, y1, ...] — 0..1 (to'g'rilangan rasm bo'yicha)
     * @param w   rasm eni (piksel), @param h rasm bo'yi (piksel)
     * @param mirror old kamera uchun oyna effekti
     */
    fun onHand(lm: FloatArray, w: Int, h: Int, mirror: Boolean) {
        if (lm.size < 42) return
        val now = SystemClock.uptimeMillis()
        val sw = svc.screenW().toFloat()
        val sh = svc.screenH().toFloat()
        if (cx < 0f) {
            cx = sw / 2f
            cy = sh / 2f
        }

        val px = FloatArray(42) // rasm pikselida (nisbatlar uchun)
        val pts = FloatArray(42) // ekran pikselida
        val m = 0.10f
        for (i in 0 until 21) {
            var x = lm[2 * i]
            val y = lm[2 * i + 1]
            if (mirror) x = 1f - x
            px[2 * i] = x * w
            px[2 * i + 1] = y * h
            pts[2 * i] = ((x - m) / (1f - 2f * m)).coerceIn(0f, 1f) * sw
            pts[2 * i + 1] = ((y - m) / (1f - 2f * m)).coerceIn(0f, 1f) * sh
        }

        val hs = max(dist(px, 0, 9), 1f)
        val ratio = dist(px, 4, 8) / hs
        val e1 = dist(px, 8, 0) > dist(px, 6, 0) * 1.1f
        val e2 = dist(px, 12, 0) > dist(px, 10, 0) * 1.1f
        val e3 = dist(px, 16, 0) > dist(px, 14, 0) * 1.1f
        val e4 = dist(px, 20, 0) > dist(px, 18, 0) * 1.1f
        val te = dist(px, 4, 5) > 0.65f * hs // bosh barmoq ochiq

        pinchOn = if (pinchOn) ratio < 0.5f else ratio < 0.3f

        val raw = when {
            pinchOn -> Mode.PINCH
            te && !e1 && !e2 && !e3 && e4 -> Mode.SHAKA
            e1 && e2 && e3 && !e4 -> Mode.VOLUME
            e1 && e2 && !e3 && !e4 -> Mode.SCROLL
            e1 && !e2 && !e3 && !e4 -> Mode.POINT
            !e1 && !e2 && !e3 && !e4 && ratio > 0.55f -> Mode.FIST
            else -> Mode.IDLE
        }

        if (raw == Mode.PINCH || mode == Mode.PINCH) {
            if (raw != mode) changeMode(raw)
            cand = null
            candN = 0
        } else {
            if (raw == cand) {
                candN++
            } else {
                cand = raw
                candN = 1
            }
            if (candN >= 3 && raw != mode) changeMode(raw)
        }

        when (mode) {
            Mode.POINT -> {
                if (ratio > 0.62f) moveCursor(gx(pts, 8), gy(pts, 8))
            }
            Mode.PINCH -> handlePinch(pts, now, sw, sh)
            Mode.SCROLL -> handleScroll(pts, sw, sh)
            Mode.VOLUME -> handleVolume(px, pts)
            Mode.SHAKA -> handleShaka(px, pts, now)
            Mode.FIST -> handleFist(pts, now)
            else -> {
            }
        }

        // Skelet shakli buzilmasligi uchun bir xil masshtabda chiziladi (ekran cho'zilmaydi);
        // kaft ekrandagi o'z joyida turadi
        val k = 0.8f * sw / w
        val ax = pts[18]
        val ay = pts[19]
        val skel = FloatArray(42)
        for (i in 0 until 21) {
            skel[2 * i] = ax + (px[2 * i] - px[18]) * k
            skel[2 * i + 1] = ay + (px[2 * i + 1] - px[19]) * k
        }

        val dragging = mode == Mode.PINCH && pinchStarted
        view.hand = skel
        view.previewW = w
        view.previewH = h
        view.preview = px
        view.show = true
        view.curX = if (dragging) dragX else cx
        view.curY = if (dragging) dragY else cy
        view.label = labelFor(mode)
        view.ringColor = colorFor(mode)
        view.pinching = mode == Mode.PINCH
        view.invalidate()
    }

    fun onLost() {
        pinchStarted = false // qo'l yo'qolsa bosish bekor qilinadi
        if (mode != Mode.NONE) changeMode(Mode.NONE)
        cand = null
        candN = 0
        pinchOn = false
        view.show = false
        view.hand = null
        view.preview = null
        view.label = ""
        view.fist = 0f
        view.invalidate()
    }

    // ---------------- Rejimlar ----------------

    private fun handlePinch(pts: FloatArray, now: Long, sw: Float, sh: Float) {
        // Barmoq uchlari yaqinlashganda o'rtasi siljiydi, shuning uchun kaft markazini kuzatamiz
        val mx = (gx(pts, 0) + gx(pts, 5) + gx(pts, 9) + gx(pts, 13) + gx(pts, 17)) / 5f
        val my = (gy(pts, 0) + gy(pts, 5) + gy(pts, 9) + gy(pts, 13) + gy(pts, 17)) / 5f
        if (!pinchStarted) {
            pinchStarted = true
            pinchT = now
            pinchX0 = cx
            pinchY0 = cy
            midX0 = mx
            midY0 = my
            dragX = cx
            dragY = cy
            moved = 0f
        } else {
            dragX = (pinchX0 + (mx - midX0)).coerceIn(0f, sw)
            dragY = (pinchY0 + (my - midY0)).coerceIn(0f, sh)
            moved = max(moved, hypot(mx - midX0, my - midY0))
        }
    }

    private fun endPinch() {
        if (!pinchStarted) return
        pinchStarted = false
        val sw = svc.screenW().toFloat()
        val now = SystemClock.uptimeMillis()
        if (moved < 0.05f * sw) {
            val held = now - pinchT
            svc.tap(pinchX0, pinchY0, if (held > 700L) 800L else 45L)
            view.ripple(pinchX0, pinchY0)
        } else {
            val len = hypot(dragX - pinchX0, dragY - pinchY0)
            val dur = (len * 0.6f).toLong().coerceIn(150L, 700L)
            svc.swipe(pinchX0, pinchY0, dragX, dragY, dur)
            cx = dragX
            cy = dragY
        }
    }

    private fun handleScroll(pts: FloatArray, sw: Float, sh: Float) {
        moveCursor((gx(pts, 8) + gx(pts, 12)) / 2f, (gy(pts, 8) + gy(pts, 12)) / 2f)
        if (!prevSX.isNaN()) {
            accX += cx - prevSX
            accY += cy - prevSY
        }
        prevSX = cx
        prevSY = cy
        val mag = hypot(accX, accY)
        if (mag > 0.045f * sh && !svc.isBusy()) {
            var vx = accX * 1.8f
            var vy = accY * 1.8f
            val len = hypot(vx, vy)
            val maxLen = 0.45f * sh
            if (len > maxLen) {
                vx *= maxLen / len
                vy *= maxLen / len
            }
            val dur = (hypot(vx, vy) * 1.4f).toLong().coerceIn(120L, 450L)
            val ox = sw / 2f
            val oy = sh / 2f
            // qo'l qaysi tomonga yursa, barmoq ham shu tomonga suriladi
            svc.swipe(ox - vx / 2f, oy - vy / 2f, ox + vx / 2f, oy + vy / 2f, dur)
            accX = 0f
            accY = 0f
        }
    }

    private fun handleVolume(px: FloatArray, pts: FloatArray) {
        moveCursor(gx(pts, 9), gy(pts, 9))
        val dx = gx(px, 9) - gx(px, 0)
        val dy = gy(px, 9) - gy(px, 0)
        val ang = Math.toDegrees(atan2(dx, -dy).toDouble()).toFloat() // tik = 0, soat mili tomoniga = musbat
        if (!volInit) {
            angSm = ang
            volInit = true
            volAcc = 0f
            return
        }
        var dd = ang - angSm
        if (dd > 180f) dd -= 360f else if (dd < -180f) dd += 360f
        angSm += dd * 0.4f
        if (angSm > 180f) angSm -= 360f else if (angSm < -180f) angSm += 360f
        volAcc += dd * 0.4f
        while (volAcc >= 14f) {
            svc.volume(true)
            volAcc -= 14f
        }
        while (volAcc <= -14f) {
            svc.volume(false)
            volAcc += 14f
        }
    }

    private fun handleShaka(px: FloatArray, pts: FloatArray, now: Long) {
        moveCursor(gx(pts, 9), gy(pts, 9))
        val dx = gx(px, 9) - gx(px, 0)
        val dy = gy(px, 9) - gy(px, 0)
        // tik = 0, o'ngga qiyshaysa musbat, chapga qiyshaysa manfiy
        val ang = Math.toDegrees(atan2(dx, -dy).toDouble()).toFloat()
        if (!shInit) {
            shInit = true
            shAng = ang
            shArmed = false
            return
        }
        shAng += (ang - shAng) * 0.5f
        if (!shArmed) {
            // avval qo'l tik holatga kelishi kerak, so'ng qiyshaytirsa ishlaydi
            if (abs(shAng) < 15f) shArmed = true
            return
        }
        if (now < cooldown) return
        if (shAng < -35f) {
            svc.back()
            cooldown = now + 900L
            shArmed = false
        } else if (shAng > 35f) {
            svc.recents()
            cooldown = now + 900L
            shArmed = false
        }
    }

    private fun handleFist(pts: FloatArray, now: Long) {
        moveCursor(gx(pts, 9), gy(pts, 9))
        if (fistStart == 0L) fistStart = now
        val p = ((now - fistStart) / 900f).coerceAtMost(1f)
        view.fist = if (fistDone) 0f else p
        if (p >= 1f && !fistDone) {
            fistDone = true
            view.fist = 0f
            svc.home()
        }
    }

    // ---------------- Yordamchi ----------------

    private fun changeMode(m: Mode) {
        if (mode == Mode.PINCH) endPinch()
        if (mode == Mode.FIST) {
            fistStart = 0L
            fistDone = false
            view.fist = 0f
        }
        prevSX = Float.NaN
        prevSY = Float.NaN
        accX = 0f
        accY = 0f
        volInit = false
        volAcc = 0f
        shInit = false
        shArmed = false
        mode = m
    }

    private fun moveCursor(tx: Float, ty: Float) {
        val sw = svc.screenW().toFloat()
        val d = hypot(tx - cx, ty - cy)
        val a = min(0.92f, 0.38f + d / (0.08f * sw)) // kursor barmoqqa tezroq ergashadi
        cx += (tx - cx) * a
        cy += (ty - cy) * a
    }

    private fun labelFor(m: Mode): String = when (m) {
        Mode.POINT -> "☝️ Kursor — bosish uchun 🤏"
        Mode.PINCH -> "🤏 Bosish / surish"
        Mode.SCROLL -> "✌️ Aylantirish"
        Mode.VOLUME -> "🤟 Ovoz — qo'lni burang"
        Mode.SHAKA -> "🤙 Chapga: Orqaga · O'ngga: So'nggilar"
        Mode.FIST -> "✊ Bosh ekran — ushlab turing"
        else -> ""
    }

    private fun colorFor(m: Mode): Int = when (m) {
        Mode.PINCH -> 0xFF4ADE80.toInt()
        Mode.SCROLL, Mode.VOLUME, Mode.FIST -> 0xFFFB923C.toInt()
        Mode.SHAKA -> 0xFFA78BFA.toInt()
        else -> 0xFF4FC3F7.toInt()
    }
}
