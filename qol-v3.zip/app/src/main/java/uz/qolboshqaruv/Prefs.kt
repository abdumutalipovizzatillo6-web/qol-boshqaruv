package uz.qolboshqaruv

import android.content.Context

object Prefs {
    private const val NAME = "hand"

    fun gpu(c: Context): Boolean = c.getSharedPreferences(NAME, 0).getBoolean("gpu", true)

    fun setGpu(c: Context, v: Boolean) {
        c.getSharedPreferences(NAME, 0).edit().putBoolean("gpu", v).apply()
    }

    fun skeleton(c: Context): Boolean = c.getSharedPreferences(NAME, 0).getBoolean("skeleton", true)

    fun setSkeleton(c: Context, v: Boolean) {
        c.getSharedPreferences(NAME, 0).edit().putBoolean("skeleton", v).apply()
    }
}
