package uz.qolboshqaruv

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val cBg = 0xFF0B0D12.toInt()
    private val cCard = 0xFF161A22.toInt()
    private val cStroke = 0xFF252C39.toInt()
    private val cFg = 0xFFEEF0F4.toInt()
    private val cSub = 0xFF9AA3B5.toInt()
    private val cAcc = 0xFF4FC3F7.toInt()
    private val cOk = 0xFF4ADE80.toInt()
    private val cWarn = 0xFFFB923C.toInt()
    private val cRed = 0xFFF87171.toInt()

    private lateinit var tvReady: TextView
    private lateinit var stCam: TextView
    private lateinit var stA11y: TextView
    private lateinit var stRun: TextView
    private lateinit var swGpu: Switch
    private lateinit var swSkel: Switch
    private var binding = false
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(top)
        p.bottomMargin = dp(bottom)
        return p
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        return tv
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.background = shape(cCard, 18, cStroke)
        parent.addView(c, lp(0, 12))
        return c
    }

    /** Qadam sarlavhasi: raqam doirasi + nom + o'ng tomonda holat belgisi. */
    private fun stepRow(card: LinearLayout, n: String, title: String): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val badge = TextView(this)
        badge.text = n
        badge.textSize = 14f
        badge.setTextColor(cBg)
        badge.setTypeface(null, Typeface.BOLD)
        badge.gravity = Gravity.CENTER
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(cAcc)
        badge.background = oval
        row.addView(badge, LinearLayout.LayoutParams(dp(28), dp(28)))

        val t = text(title, 17f, cFg, true)
        t.setPadding(dp(10), 0, dp(8), 0)
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val st = text("", 20f, cFg)
        row.addView(st)
        card.addView(row, lp(0, 6))
        return st
    }

    private fun btn(t: String, fill: Int, textColor: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 15f
        b.setTextColor(textColor)
        b.setTypeface(null, Typeface.BOLD)
        b.background = shape(fill, 14)
        b.stateListAnimator = null
        b.minHeight = dp(48)
        b.minimumHeight = dp(48)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun gestureRow(card: LinearLayout, emoji: String, title: String, desc: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val e = text(emoji, 26f, cFg)
        e.gravity = Gravity.CENTER
        row.addView(e, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), 0, 0, 0)
        col.addView(text(title, 15f, cFg, true))
        col.addView(text(desc, 13f, cSub))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        card.addView(row, lp(0, 10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(40), dp(16), dp(28))

        // ---- Sarlavha ----
        root.addView(text("✋ Qol bilan boshqarish", 28f, cFg, true), lp(0, 4))
        root.addView(
            text(
                "Old kamera qo'lingizni kuzatadi — telefonni tegmasdan boshqarasiz.",
                14f, cSub
            ), lp(0, 12)
        )
        tvReady = text("", 14f, cOk, true)
        tvReady.setPadding(dp(14), dp(10), dp(14), dp(10))
        root.addView(tvReady, lp(0, 14))

        // ---- 1-qadam ----
        val c1 = card(root)
        stCam = stepRow(c1, "1", "Kameraga ruxsat")
        c1.addView(text("Old kamera qo'lingizni ko'rishi uchun kerak. Rasm saqlanmaydi va hech qayerga yuborilmaydi.", 13f, cSub), lp(0, 10))
        c1.addView(btn("Kameraga ruxsat berish", cAcc, cBg) { askPermissions() })

        // ---- 2-qadam ----
        val c2 = card(root)
        stA11y = stepRow(c2, "2", "Maxsus imkoniyatlar")
        c2.addView(
            text(
                "Ilovalarni bosish va surish uchun kerak. «Qol boshqaruv» ni topib yoqing.\n" +
                    "Yoqib bo'lmasa (Android 13+): pastdagi ikkinchi tugma → ⋮ (yuqori o'ng) → «Cheklangan sozlamalarga ruxsat berish», so'ng qayta urinib ko'ring.",
                13f, cSub
            ), lp(0, 10)
        )
        c2.addView(btn("Maxsus imkoniyatlarni ochish", cAcc, cBg) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        c2.addView(btn("Ilova sozlamalari (cheklangan sozlama)", 0xFF2A3140.toInt(), cFg) {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        }, lp(8, 0))

        // ---- 3-qadam ----
        val c3 = card(root)
        stRun = stepRow(c3, "3", "Ishga tushirish")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bStart = btn("▶  Boshlash", cOk, cBg) { start() }
        val bStop = btn("■  To'xtatish", 0xFF3A2024.toInt(), cRed) {
            stopService(Intent(this, CameraService::class.java))
            refreshLater()
        }
        val half = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        half.rightMargin = dp(6)
        val half2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        half2.leftMargin = dp(6)
        row.addView(bStart, half)
        row.addView(bStop, half2)
        c3.addView(row, lp(0, 0))

        // ---- Tezlik ----
        val c4 = card(root)
        c4.addView(text("⚡ Tezlik sozlamalari", 17f, cFg, true), lp(0, 8))
        swGpu = Switch(this)
        swGpu.text = "GPU bilan tezlashtirish"
        swGpu.textSize = 15f
        swGpu.setTextColor(cFg)
        swGpu.setOnCheckedChangeListener { _, on ->
            if (!binding) {
                Prefs.setGpu(this, on)
                Toast.makeText(this, "O'zgarish uchun «To'xtatish», so'ng qayta «Boshlash» bosing", Toast.LENGTH_LONG).show()
            }
        }
        c4.addView(swGpu, lp(0, 4))
        c4.addView(text("Qo'l sekin topilsa yoqilgan tursin. Kamera qotsa — o'chiring.", 12f, cSub), lp(0, 10))
        swSkel = Switch(this)
        swSkel.text = "Qo'l skeletini ko'rsatish"
        swSkel.textSize = 15f
        swSkel.setTextColor(cFg)
        swSkel.setOnCheckedChangeListener { _, on ->
            if (!binding) {
                Prefs.setSkeleton(this, on)
                HandAccessibilityService.instance?.reloadPrefs()
            }
        }
        c4.addView(swSkel, lp(0, 4))
        c4.addView(text("O'chirsangiz telefon biroz yengilroq ishlaydi.", 12f, cSub))

        // ---- Imo-ishoralar ----
        val c5 = card(root)
        c5.addView(text("Imo-ishoralar", 17f, cFg, true), lp(0, 10))
        gestureRow(c5, "☝️", "1 barmoq", "Kursor qo'lingizga ergashadi")
        gestureRow(c5, "🤏", "Chimchilash", "Bosish. Ushlab tursangiz — uzoq bosish; chimchilab sudrasangiz — surish")
        gestureRow(c5, "✌️", "2 barmoq", "Qo'lni tepaga/pastga/yonga yursangiz sahifa suriladi")
        gestureRow(c5, "🤟", "3 barmoq", "Qo'lni tugmadek buring — ovoz balandligi")
        gestureRow(c5, "🤙", "Shaka", "Bosh va jimjiloq ochiq. Qo'lni tik tuting, so'ng chapga qiyshaytiring — Orqaga, o'ngga — So'nggi ilovalar")
        gestureRow(c5, "✊", "Musht", "1 soniya ushlab turing — Bosh ekran")

        // ---- Xiaomi ----
        val c6 = card(root)
        c6.addView(text("Xiaomi / Redmi uchun", 17f, cFg, true), lp(0, 6))
        c6.addView(
            text(
                "Ilova fonda to'xtab qolmasligi uchun: Sozlamalar → Ilovalar → Qol boshqaruv → " +
                    "«Avto-ishga tushirish» ni yoqing va Batareya tejash: «Cheklovsiz» ni tanlang.\n" +
                    "To'xtatish: bildirishnomadagi «To'xtatish» tugmasi.",
                13f, cSub
            )
        )

        root.addView(text("Versiya 3 · tezkor + 🤙 shaka", 12f, cSub).also { it.gravity = Gravity.CENTER }, lp(4, 0))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun camGranted(): Boolean =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, HandAccessibilityService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return s.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun refresh() {
        val cam = camGranted()
        val a11y = a11yEnabled()
        stCam.text = if (cam) "✅" else "❌"
        stA11y.text = if (a11y) "✅" else "❌"
        stRun.text = if (CameraService.running) "🟢" else "⚪"

        if (cam && a11y) {
            tvReady.text = if (CameraService.running) "🟢 Ishlayapti — qo'lingizni old kameraga ko'rsating" else "✅ Hammasi tayyor — «Boshlash» ni bosing"
            tvReady.setTextColor(cOk)
            tvReady.background = shape(0xFF12301F.toInt(), 12)
        } else {
            tvReady.text = "⚠️ Avval 1 va 2-qadamni bajaring"
            tvReady.setTextColor(cWarn)
            tvReady.background = shape(0xFF3A2410.toInt(), 12)
        }

        binding = true
        swGpu.isChecked = Prefs.gpu(this)
        swSkel.isChecked = Prefs.skeleton(this)
        binding = false
    }

    private fun refreshLater() {
        handler.postDelayed({ refresh() }, 600L)
    }

    private fun askPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.CAMERA)
        }
        requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun start() {
        if (!camGranted()) {
            Toast.makeText(this, "Avval kameraga ruxsat bering", Toast.LENGTH_LONG).show()
            return
        }
        if (!a11yEnabled()) {
            Toast.makeText(this, "Avval Maxsus imkoniyatlarda yoqing", Toast.LENGTH_LONG).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        Toast.makeText(this, "Ishga tushdi. Qo'lingizni old kameraga ko'rsating", Toast.LENGTH_LONG).show()
        refreshLater()
        moveTaskToBack(true)
    }
}
